#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Servidor local para APK Recargador Universal MODIFICADA.
Guarda un log detallado de TODO lo que pasa.
"""
import http.server
import socketserver
import os
import json
import urllib.parse
from datetime import datetime

PORT = 8443
CACHE_DIR = r"C:\recargador_local\cache"
RESP_DIR = os.path.join(CACHE_DIR, "responses")
FW_DIR = r"C:\recargador_local\firmware"
FD_DIR = r"C:\recargador_local\FileDownloads"
LOG_FILE = os.path.join(CACHE_DIR, "requests.log")
LOG_TXT = os.path.join(CACHE_DIR, "log.txt")

ENDPOINT_MAP = {
    "Login.php":               "Login.json",
    "getVersion.php":          "getVersion.json",
    "IntentoRecarga.php":      None,
    "RegisterEmail.php":       "RegisterEmail.json",
    "ModificarPerfil.php":     "ModificarPerfil.json",
    "TransferirCredito.php":   "TransferirCredito.json",
    "getUserHistorial.php":    "getUserHistorial.json",
    "getUserList.php":         "getUserList.json",
    "ResultadoRecarga.php":    "ResultadoRecarga.json",
    "RecuperarPassword.php":   "RecuperarPassword.json",
    "acceptTerms.php":         "ResultadoRecarga.json",
    "SaveDeviceConnection.php": "ResultadoRecarga.json",
    "FileUpload.php":          "ResultadoRecarga.json",
}

# Tamaño de la respuesta que se guarda en el log (en bytes). 0 = completo
MAX_RESP_LOG = 500

class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        # Silenciar logs por defecto de http.server
        pass

    def _read_body(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        if length > 0:
            return self.rfile.read(length).decode("utf-8", errors="replace")
        return ""

    def _log_txt(self, line):
        """Log simple legible por humanos"""
        try:
            with open(LOG_TXT, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass

    def _log_json(self, entry):
        """Log estructurado en JSON (para parsear)"""
        try:
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def do_GET(self):
        body = self._read_body()
        self._handle("GET", body)

    def do_POST(self):
        body = self._read_body()
        self._handle("POST", body)

    def _handle(self, method, body):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        filename = os.path.basename(path)
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # ----- Log inicial -----
        print(f"\n[{ts}] {method} {self.path}", flush=True)
        if body:
            print(f"  BODY ({len(body)}b): {body[:200]}", flush=True)

        # Preparar entrada de log JSON
        entry = {
            "ts": ts,
            "method": method,
            "path": self.path,
            "path_clean": path,
            "endpoint": filename,
            "client": self.client_address[0],
            "headers": dict(self.headers),
            "body": body,
            "response_type": None,
            "response_file": None,
            "response_size": None,
            "response_preview": None,
            "status_code": None,
        }

        # ====================================================
        #  1) Firmwares de FIRMWARES/
        # ====================================================
        if "FIRMWARES" in path.upper() or ("FileDownloads" not in path and filename.endswith(".bin")):
            fw_path = os.path.join(FW_DIR, filename)
            if os.path.exists(fw_path):
                size = os.path.getsize(fw_path)
                print(f"  -> FIRMWARE: {filename} ({size} bytes)", flush=True)
                entry["response_type"] = "firmware"
                entry["response_file"] = filename
                entry["response_size"] = size
                entry["status_code"] = 200
                self._log_json(entry)
                self._log_txt(f"[{ts}] {method} {path} -> FIRMWARE {filename} ({size}b)")
                return self._send_file(fw_path)
            else:
                print(f"  -> FIRMWARE NO ENCONTRADO: {filename}", flush=True)
                entry["response_type"] = "error"
                entry["response_preview"] = "Firmware no encontrado"
                entry["status_code"] = 404
                self._log_json(entry)
                self._log_txt(f"[{ts}] {method} {path} -> 404 FIRMWARE NOT FOUND {filename}")
                return self._send_error(404, "Firmware no encontrado")

        # ====================================================
        #  2) FileDownloads/
        # ====================================================
        if "FileDownloads" in path:
            fd_path = os.path.join(FD_DIR, filename)
            if os.path.exists(fd_path):
                size = os.path.getsize(fd_path)
                print(f"  -> FILEDOWNLOAD: {filename} ({size} bytes)", flush=True)
                entry["response_type"] = "filedownload"
                entry["response_file"] = filename
                entry["response_size"] = size
                entry["status_code"] = 200
                self._log_json(entry)
                self._log_txt(f"[{ts}] {method} {path} -> FILEDOWNLOAD {filename} ({size}b)")
                return self._send_file(fd_path)
            else:
                print(f"  -> FILEDOWNLOAD NO ENCONTRADO: {filename}", flush=True)
                entry["response_type"] = "error"
                entry["response_preview"] = "Archivo no encontrado"
                entry["status_code"] = 404
                self._log_json(entry)
                self._log_txt(f"[{ts}] {method} {path} -> 404 FILEDOWNLOAD NOT FOUND {filename}")
                return self._send_error(404, "Archivo no encontrado")

        # ====================================================
        #  3) IntentoRecarga.php
        # ====================================================
        if filename == "IntentoRecarga.php":
            response = '{"Result":"ok"}'
            print(f"  -> IntentoRecarga autorizada", flush=True)
            entry["response_type"] = "json_dynamic"
            entry["response_preview"] = response
            entry["response_size"] = len(response)
            entry["status_code"] = 200
            self._log_json(entry)
            self._log_txt(f"[{ts}] {method} {path} -> IntentoRecarga OK")
            return self._send_json(response)

        # ====================================================
        #  4) Otros endpoints con JSON cacheado
        # ====================================================
        if filename in ENDPOINT_MAP and ENDPOINT_MAP[filename]:
            json_file = os.path.join(RESP_DIR, ENDPOINT_MAP[filename])
            if os.path.exists(json_file):
                with open(json_file, "r", encoding="utf-8") as f:
                    content = f.read()
                size = len(content)
                preview = content[:MAX_RESP_LOG] if MAX_RESP_LOG > 0 else content
                print(f"  -> {ENDPOINT_MAP[filename]} servido ({size}b)", flush=True)
                entry["response_type"] = "json_cached"
                entry["response_file"] = ENDPOINT_MAP[filename]
                entry["response_size"] = size
                entry["response_preview"] = preview
                entry["status_code"] = 200
                self._log_json(entry)
                self._log_txt(f"[{ts}] {method} {path} -> {ENDPOINT_MAP[filename]} ({size}b)")
                return self._send_json(content)
            else:
                print(f"  -> JSON NO ENCONTRADO: {json_file}", flush=True)
                entry["response_type"] = "error"
                entry["response_preview"] = f"Cache not found: {json_file}"
                entry["status_code"] = 404
                self._log_json(entry)
                self._log_txt(f"[{ts}] {method} {path} -> 404 CACHE NOT FOUND {json_file}")
                return self._send_error(404, "Cache not found")

        # ====================================================
        #  5) Endpoint desconocido
        # ====================================================
        print(f"  -> Endpoint no usado: {filename}", flush=True)
        entry["response_type"] = "empty"
        entry["response_preview"] = "{}"
        entry["response_size"] = 2
        entry["status_code"] = 200
        self._log_json(entry)
        self._log_txt(f"[{ts}] {method} {path} -> {{}} (no usado)")
        return self._send_json("{}")

    def _send_json(self, content):
        data = content.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=UTF-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_file(self, path):
        with open(path, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_error(self, code, msg):
        body = json.dumps({"error": msg}).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    os.makedirs(RESP_DIR, exist_ok=True)
    os.makedirs(FW_DIR, exist_ok=True)
    os.makedirs(FD_DIR, exist_ok=True)

    # Crear/limpiar log al iniciar
    with open(LOG_TXT, "a", encoding="utf-8") as f:
        f.write("\n" + "=" * 70 + "\n")
        f.write(f"  SERVIDOR INICIADO {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("=" * 70 + "\n")

    print("=" * 60)
    print(f"  SERVIDOR LOCAL RECARGADOR UNIVERSAL (v3 - con LOG)")
    print(f"  http://0.0.0.0:{PORT}")
    print(f"  Log legible: {LOG_TXT}")
    print(f"  Log JSON:    {LOG_FILE}")
    print(f"  Ctrl+C para detener")
    print("=" * 60)

    with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
        httpd.serve_forever()